# This package is used for extracting water resource data from USGS (https://waterservices.usgs.gov/rest/IV-Service.html)

## The function get_data(state, start_date=None, end_date=None, site_type=None, status='all') requires input of state, date nad site information.